<template>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <h2 class="text-center mb-4">Formulario de Registro</h2>
        <p class="text-center mb-4">Por favor complete todos los campos requeridos</p>

        <form @submit.prevent="handleSubmit" class="needs-validation" novalidate>
          <div class="mb-3">
            <label for="name" class="form-label">Nombre</label>
            <input
              type="text"
              class="form-control"
              id="name"
              v-model="formData.name"
              :class="{ 'is-invalid': errors.name }"
              required
            >
            <div class="invalid-feedback" v-if="errors.name">
              {{ errors.name }}
            </div>
          </div>

          <!-- Nuevo campo: Número telefónico -->
          <div class="mb-3">
            <label for="phone" class="form-label">Número Telefónico</label>
            <input
              type="tel"
              class="form-control"
              id="phone"
              v-model="formData.phone"
              :class="{ 'is-invalid': errors.phone }"
              required
            >
            <div class="invalid-feedback" v-if="errors.phone">
              {{ errors.phone }}
            </div>
          </div>

          <!-- Nuevo campo: Fecha de nacimiento -->
          <div class="mb-3">
            <label for="birthdate" class="form-label">Fecha de Nacimiento</label>
            <input
              type="date"
              class="form-control"
              id="birthdate"
              v-model="formData.birthdate"
              :class="{ 'is-invalid': errors.birthdate }"
              required
            >
            <div class="invalid-feedback" v-if="errors.birthdate">
              {{ errors.birthdate }}
            </div>
          </div>

          <div class="mb-3">
            <label for="email" class="form-label">Correo Electrónico</label>
            <input
              type="email"
              class="form-control"
              id="email"
              v-model="formData.email"
              :class="{ 'is-invalid': errors.email }"
              required
            >
            <div class="invalid-feedback" v-if="errors.email">
              {{ errors.email }}
            </div>
          </div>

          <div class="mb-3">
            <label for="password" class="form-label">Contraseña</label>
            <input
              type="password"
              class="form-control"
              id="password"
              v-model="formData.password"
              :class="{ 'is-invalid': errors.password }"
              required
            >
            <div class="invalid-feedback" v-if="errors.password">
              {{ errors.password }}
            </div>
          </div>

          <button type="submit" class="btn btn-primary w-100">Enviar</button>
        </form>

        <div v-if="submitted" class="alert alert-success mt-3">
          Formulario enviado exitosamente
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useFormStore } from '../stores/formStore'

const store = useFormStore()
const submitted = ref(false)

const formData = reactive({
  name: '',
  phone: '', // Nuevo campo
  birthdate: '', // Nuevo campo
  email: '',
  password: ''
})

const errors = reactive({
  name: '',
  phone: '', // Nuevo campo
  birthdate: '', // Nuevo campo
  email: '',
  password: ''
})

const validateForm = () => {
  let isValid = true
  errors.name = ''
  errors.phone = ''
  errors.birthdate = ''
  errors.email = ''
  errors.password = ''

  if (!formData.name) {
    errors.name = 'El nombre es requerido'
    isValid = false
  }

  // Validación para número telefónico
  if (!formData.phone) {
    errors.phone = 'El número telefónico es requerido'
    isValid = false
  } else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
    errors.phone = 'Ingrese un número telefónico válido (10 dígitos)'
    isValid = false
  }

  // Validación para fecha de nacimiento
  if (!formData.birthdate) {
    errors.birthdate = 'La fecha de nacimiento es requerida'
    isValid = false
  } else {
    const today = new Date()
    const birthDate = new Date(formData.birthdate)
    if (birthDate > today) {
      errors.birthdate = 'La fecha de nacimiento no puede ser en el futuro'
      isValid = false
    }
  }

  if (!formData.email) {
    errors.email = 'El correo electrónico es requerido'
    isValid = false
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Ingrese un correo electrónico válido'
    isValid = false
  }

  if (!formData.password) {
    errors.password = 'La contraseña es requerida'
    isValid = false
  } else if (formData.password.length < 6) {
    errors.password = 'La contraseña debe tener al menos 6 caracteres'
    isValid = false
  }

  return isValid
}

const handleSubmit = () => {
  if (validateForm()) {
    store.submitForm(formData)
    submitted.value = true
    setTimeout(() => {
      submitted.value = false
    }, 3000)
  }
}
</script>