<template>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Gestión de Usuarios</h2>
    
    <div v-if="users.length === 0" class="alert alert-info">
      No hay usuarios registrados aún.
    </div>
    
    <div v-else class="table-responsive">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Teléfono</th>
            <th>Fecha de Nacimiento</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.id">
            <td>{{ user.name }}</td>
            <td>{{ user.email }}</td>
            <td>{{ user.phone }}</td>
            <td>{{ formatDate(user.birthdate) }}</td>
            <td>
              <button class="btn btn-info btn-sm me-1" @click="viewDetails(user)">
                <i class="bi bi-eye"></i> Ver
              </button>
              <button class="btn btn-warning btn-sm me-1" @click="editUser(user)">
                <i class="bi bi-pencil"></i> Editar
              </button>
              <button class="btn btn-danger btn-sm" @click="confirmDelete(user)">
                <i class="bi bi-trash"></i> Eliminar
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Modal para ver detalles -->
    <div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true" ref="detailsModalRef">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Detalles del Usuario</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" v-if="selectedUser">
            <div class="mb-3">
              <strong>Nombre:</strong> {{ selectedUser.name }}
            </div>
            <div class="mb-3">
              <strong>Correo:</strong> {{ selectedUser.email }}
            </div>
            <div class="mb-3">
              <strong>Teléfono:</strong> {{ selectedUser.phone }}
            </div>
            <div class="mb-3">
              <strong>Fecha de Nacimiento:</strong> {{ formatDate(selectedUser.birthdate) }}
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para editar usuario -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true" ref="editModalRef">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Editar Usuario</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="saveEdit">
              <div class="mb-3">
                <label for="edit-name" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="edit-name" v-model="editedUser.name" required>
              </div>
              <div class="mb-3">
                <label for="edit-email" class="form-label">Correo Electrónico</label>
                <input type="email" class="form-control" id="edit-email" v-model="editedUser.email" required>
              </div>
              <div class="mb-3">
                <label for="edit-phone" class="form-label">Teléfono</label>
                <input type="tel" class="form-control" id="edit-phone" v-model="editedUser.phone" required>
              </div>
              <div class="mb-3">
                <label for="edit-birthdate" class="form-label">Fecha de Nacimiento</label>
                <input type="date" class="form-control" id="edit-birthdate" v-model="editedUser.birthdate" required>
              </div>
              <div class="text-end">
                <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de confirmación para eliminar -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true" ref="deleteModalRef">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Confirmar Eliminación</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>¿Está seguro que desea eliminar a <strong>{{ selectedUser?.name }}</strong>?</p>
            <p class="text-danger">Esta acción no se puede deshacer.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-danger" @click="deleteUser">Eliminar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useFormStore } from '../stores/formStore'
import { Modal } from 'bootstrap'

const store = useFormStore()
const users = computed(() => store.users)

const selectedUser = ref(null)
const editedUser = ref({})

// Referencias para los modales
const detailsModalRef = ref(null)
const editModalRef = ref(null)
const deleteModalRef = ref(null)

// Instancias de los modales
let detailsModal = null
let editModal = null
let deleteModal = null

onMounted(() => {
  // Inicializar los modales
  detailsModal = new Modal(detailsModalRef.value)
  editModal = new Modal(editModalRef.value)
  deleteModal = new Modal(deleteModalRef.value)
})

// Formatear fecha para mostrar
const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleDateString()
}

// Ver detalles del usuario
const viewDetails = (user) => {
  selectedUser.value = user
  detailsModal.show()
}

// Editar usuario
const editUser = (user) => {
  selectedUser.value = user
  editedUser.value = { ...user }
  editModal.show()
}

// Guardar cambios de edición
const saveEdit = () => {
  store.updateUser(editedUser.value)
  editModal.hide()
}

// Confirmar eliminación
const confirmDelete = (user) => {
  selectedUser.value = user
  deleteModal.show()
}

// Eliminar usuario
const deleteUser = () => {
  store.deleteUser(selectedUser.value.id)
  deleteModal.hide()
}
</script>