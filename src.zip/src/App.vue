<template>
  <div class="app-container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
      <div class="container">
        <router-link class="navbar-brand" to="/">Formulario Dinámico</router-link>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <router-link class="nav-link" to="/">Registro</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/users">Gestión de Usuarios</router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <router-view></router-view>
  </div>
</template>

<script setup>
</script>

<style>
body {
  background-color: #37617d; /* Color de fondo azul claro */
  min-height: 100vh;
}

.app-container {
  min-height: 100vh;
}

/* Estilos adicionales para mejorar la apariencia de los componentes */
.card, .table {
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.container {
  padding-bottom: 2rem;
}
</style>
