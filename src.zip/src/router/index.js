import { createRouter, createWebHistory } from 'vue-router'
import DynamicForm from '../components/DynamicForm.vue'
import UserManagement from '../components/UserManagement.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: DynamicForm
  },
  {
    path: '/users',
    name: 'users',
    component: UserManagement
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router