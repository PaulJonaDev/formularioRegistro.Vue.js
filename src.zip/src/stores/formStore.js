import { defineStore } from 'pinia'

export const useFormStore = defineStore('form', {
  state: () => ({
    formData: {
      name: '',
      phone: '',
      birthdate: '',
      email: '',
      password: ''
    },
    users: [],
    isSubmitted: false
  }),
  actions: {
    submitForm(data) {
      // Crear una copia del objeto con un ID único
      const newUser = {
        ...data,
        id: Date.now().toString()
      }
      this.users.push(newUser)
      this.formData = {
        name: '',
        phone: '',
        birthdate: '',
        email: '',
        password: ''
      }
      this.isSubmitted = true
    },
    deleteUser(id) {
      this.users = this.users.filter(user => user.id !== id)
    },
    updateUser(updatedUser) {
      const index = this.users.findIndex(user => user.id === updatedUser.id)
      if (index !== -1) {
        this.users[index] = updatedUser
      }
    }
  },
  persist: {
    enabled: true,
    strategies: [
      { storage: localStorage }
    ]
  }
})