# Formulario Dinámico Vue.js

## Versión de Vue
- Vue 3.x
- Vite como build tool

## Instalación
1. Clonar el repositorio
2. Instalar dependencias:
```npm install```
3. Ejecutar el proyecto:
```npm run dev```

## Descripción
Formulario dinámico interactivo con validaciones y diseño responsivo utilizando Bootstrap.

### Funcionalidades
- Validación de campos en tiempo real
- Mensajes de error personalizados
- Diseño responsivo
- Manejo de estado con Pinia
- Navegación con Vue Router
- Campos para datos personales (nombre, teléfono, fecha de nacimiento)
- Campos para credenciales (correo electrónico, contraseña)
- Gestión completa de usuarios (CRUD):
  - Listado de usuarios registrados
  - Visualización de detalles de usuario
  - Edición de información de usuario
  - Eliminación de usuarios

### Tecnologías utilizadas
- Vue.js 3
- Bootstrap 5
- Pinia
- Vue Router
